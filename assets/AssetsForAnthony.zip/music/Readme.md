# Credits:

**Ember#1765 / DeerTears:**

- fast wind gust.mod
- harsh wind gust.mod
- menu no thanks.mod
- nuh-uh.mod
- odd open inventory.mod
- old telephone 1.mod
- racecar zoom.mod
- smb3okay.mod
